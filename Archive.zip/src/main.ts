import { fetchRandomQuote, fetchImage } from "./api";

const btn = document.getElementById("btn") as HTMLButtonElement;
const card = document.getElementById("card") as HTMLDivElement;
const skeleton = document.getElementById("skeleton") as HTMLDivElement;
const errorBox = document.getElementById("error-box") as HTMLDivElement;
const quoteText = document.getElementById("quote-text") as HTMLElement;
const charName = document.getElementById("char-name") as HTMLElement;
const animeName = document.getElementById("anime-name") as HTMLElement;
const charImg = document.getElementById("char-img") as HTMLImageElement;
const imgPlaceholder = document.getElementById(
  "img-placeholder",
) as HTMLDivElement;

function show(el: HTMLElement) {
  el.classList.remove("hidden");
}
function hide(el: HTMLElement) {
  el.classList.add("hidden");
}

async function rollQuote() {
  btn.disabled = true;
  btn.classList.add("loading");
  hide(card);
  hide(errorBox);
  show(skeleton);

  try {
    const quote = await fetchRandomQuote();
    const character = quote.character?.name ?? "Unknown";
    const anime = quote.anime?.name ?? "Unknown";

    // Fetch image concurrently while we update the text
    const imgUrl = await fetchImage(character, anime);

    // Populate card
    quoteText.textContent = `"${quote.content}"`;
    charName.textContent = character;
    animeName.textContent = anime;

    if (imgUrl) {
      charImg.src = imgUrl;
      charImg.alt = `${character} from ${animeName}`;

      charImg.onload = () => {
        charImg.style.opacity = "1"; // Fade in
        show(charImg);
        hide(imgPlaceholder);
      };

      charImg.onerror = () => {
        hide(charImg);
        show(imgPlaceholder);
      };
    } else {
      hide(charImg);
      show(imgPlaceholder);
    }

    // Animate card in
    hide(skeleton);
    show(card);
    card.classList.remove("pop");
    void card.offsetWidth; // force reflow
    card.classList.add("pop");
  } catch (err) {
    console.error(err);
    hide(skeleton);
    show(errorBox);
  } finally {
    btn.disabled = false;
    btn.classList.remove("loading");
  }
}

btn.addEventListener("click", rollQuote);

// Auto-load on first visit
rollQuote();
