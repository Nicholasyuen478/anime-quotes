import axios from "axios";

const ANIMECHAN_BASE = "https://api.animechan.io/v1";
const ANILIST_API = "https://graphql.anilist.co";
const JIKAN_BASE = "https://api.jikan.moe/v4";

// ✅ CORRECTED Interface from your actual data
export interface Quote {
  content: string;
  character: { id: number; name: string };
  anime: { id: number; name: string; altName?: string };
  status: string;
}

// ── 1. AnimeChan (FIXED) ─────────────────────────────────────────────────────
export async function fetchRandomQuote(): Promise<Quote> {
  const { data } = await axios.get(`${ANIMECHAN_BASE}/quotes/random`);
  console.log("AnimeChan response:", data); // Keep for debugging
  return data.data;
}

// ── 2. AniList — search character image ──────────────────────────────────────
const ANILIST_CHARACTER_QUERY = `
query ($name: String) {
  Character(search: $name) {
    name { full }
    image { large }
  }
}`;

const ANILIST_ANIME_QUERY = `
query ($name: String) {
  Media(search: $name, type: ANIME) {
    title { romaji english }
    coverImage { extraLarge }
  }
}`;

async function queryAniList(query: string, variables: object): Promise<any> {
  const { data } = await axios.post(ANILIST_API, { query, variables });
  
  if (data.errors) {
    throw new Error(data.errors[0].message);
  }
  
  return data.data;
}

export async function fetchImageFromAniList(
  characterName: string,
  animeName: string
): Promise<string | null> {
  // Try character first (Shikaku Nara)
  try {
    const data = await queryAniList(ANILIST_CHARACTER_QUERY, {
      name: characterName,
    });
    const img = data?.Character?.image?.large;
    if (img) return img;
  } catch (_) {}

  // Fallback to anime (Naruto)
  try {
    const data = await queryAniList(ANILIST_ANIME_QUERY, { name: animeName });
    const img = data?.Media?.coverImage?.extraLarge;
    if (img) return img;
  } catch (_) {}

  return null;
}

// ── 3. Jikan fallback ─────────────────────────────────────────────────────────
export async function fetchImageFromJikan(
  characterName: string,
  animeName: string
): Promise<string | null> {
  // Character first (Shikaku Nara)
  try {
    const { data } = await axios.get(
      `${JIKAN_BASE}/characters?q=${encodeURIComponent(characterName)}&limit=1`
    );
    const img = data?.data?.[0]?.images?.jpg?.image_url;
    if (img) return img;
  } catch (_) {}

  // Anime fallback (Naruto)
  try {
    const { data } = await axios.get(
      `${JIKAN_BASE}/anime?q=${encodeURIComponent(animeName)}&limit=1`
    );
    const img = data?.data?.[0]?.images?.jpg?.large_image_url;
    if (img) return img;
  } catch (_) {}

  return null;
}

// ── Orchestrator (uses real names) ────────────────────────────────────────────
export async function fetchImage(
  characterName: string,
  animeName: string
): Promise<string | null> {
  console.log(`Searching images for: "${characterName}" from "${animeName}"`);
  
  const anilistImg = await fetchImageFromAniList(characterName, animeName);
  if (anilistImg) {
    console.log("✅ AniList image found");
    return anilistImg;
  }
  
  const jikanImg = await fetchImageFromJikan(characterName, animeName);
  if (jikanImg) {
    console.log("✅ Jikan image found");
    return jikanImg;
  }
  
  console.warn("❌ No image found");
  return null;
}
